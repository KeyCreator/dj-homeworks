from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def hello_view(request):
    return HttpResponse('Всем привет!!!')


def number_view(request, number):
    print('Before ', number)
    number += 100
    print('After ', number)
    return HttpResponse(f'Вы ввели число {number}')
